# My First Project > 2025-11-02 12:35pm
https://universe.roboflow.com/edison-p91x6/my-first-project-ibuft

Provided by a Roboflow user
License: CC BY 4.0

